package testcases;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import testpages.Additempage;
import testpages.loginpage;
import testpages.orderpage;
import testpages.removeitempage;
import testpages.resetpage;
import testpages.shoppingpage;

public class testrunner {
	 public static WebDriver driver;
	loginpage pagefactory;
	Additempage lastitem;
	shoppingpage thirditem;
	removeitempage removeitem;
	orderpage orderitem;
	resetpage menubar;
	
	@BeforeTest
	public void launchBrowser_login() throws InterruptedException
	{
		//WebDriverManager.chromedriver().create();
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.get("https://www.saucedemo.com/");
		
		
		pagefactory = new loginpage(driver);
		pagefactory.userlogin();
		}
	
	
	@Test(priority=0,enabled=true)
	public void addlastitem() throws InterruptedException {
		
		lastitem=new Additempage(driver);
		lastitem.selectProduct();
		
	}
	
	@Test(priority=1, enabled=false)
	public void continushopping() throws InterruptedException {
		thirditem=new shoppingpage(driver);
		thirditem.Clickcontinueshopping();
		
	}
	
	@Test(priority=2, enabled=false)
	public void removeitem3() throws InterruptedException {
		removeitem=new removeitempage(driver);
		removeitem.removeproduct();
		
	}
	
	@Test(priority=3, enabled=false)
	public void orderitems() throws InterruptedException {
		orderitem=new orderpage(driver);
		orderitem.orderproducts();
		
	}
	
	@Test(priority=4, enabled=false)
	public void resetappstate() throws InterruptedException {
		menubar=new resetpage(driver);
		menubar.resetstateapp();
		
	}
	

}
