package testpages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class resetpage {
	
	@FindBy(xpath="//select[@class='product_sort_container']")
	WebElement dropdown;
	@FindBy(xpath="//button[@id ='add-to-cart-sauce-labs-onesie']")
	WebElement item1;
	@FindBy(xpath="//button[@id = 'add-to-cart-sauce-labs-bike-light']")
	WebElement item2;
	@FindBy(xpath="//button[@id = 'add-to-cart-sauce-labs-fleece-jacket']")
	WebElement item3;
	@FindBy(xpath="	//span[@class='shopping_cart_badge']")
	WebElement cartitemno;
	@FindBy(xpath="//*[@class = 'shopping_cart_link']")
	WebElement carticon;
	@FindBy(xpath="//button[@id='react-burger-menu-btn']")
	WebElement menubtn;
	@FindBy(xpath="//a[@id='reset_sidebar_link']")
	WebElement resetbtn;
	@FindBy(xpath="//button[@id='react-burger-cross-btn']")
	WebElement closebtn;
	@FindBy(xpath="//a[@id='logout_sidebar_link']")
	WebElement logout;
	

	
	WebDriver driver;
	 
	 public resetpage(WebDriver driver) {
		 this.driver = driver;
			PageFactory.initElements(driver, this);
	 }
	 
	 
	 public void resetstateapp() throws InterruptedException {
		 Select name= new Select(dropdown);
			Thread.sleep(3000);
			name.selectByValue("za");
			

			item1.click();
			Thread.sleep(3000);
			item2.click();
			Thread.sleep(3000);
			item3.click();
			Thread.sleep(3000);
		    System.out.println("no of items in cart"+cartitemno.getText());
		    String no=cartitemno.getText();
		    assertEquals("3",no);
		    carticon.click();
		    Thread.sleep(3000);
		    menubtn.click();
		    Thread.sleep(3000);
		    resetbtn.click();
		    Thread.sleep(3000);
		    carticon.click();
		    Thread.sleep(3000);
		    closebtn.click();
		    Thread.sleep(3000);
		    
		    if(carticon.getText()=="")
		    {
		    	System.out.println("cart is empty");
		    }
		    else {
		    	System.out.println("cart is not  empty");
		    }
		   // System.out.println(cartitemno.getText());
		   // Thread.sleep(3000);
		    menubtn.click();
		    Thread.sleep(3000);
		    logout.click();
		    
		 
		 
	 }

}
