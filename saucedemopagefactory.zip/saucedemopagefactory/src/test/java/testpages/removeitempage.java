package testpages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//scenario3

public class removeitempage {
	@FindBy(xpath="//button[@id='add-to-cart-sauce-labs-bolt-t-shirt']")
	WebElement item3;
	@FindBy(xpath="//button[@id='add-to-cart-sauce-labs-backpack']")
	WebElement item1;
	@FindBy(xpath="//*[@class='shopping_cart_link']")
	WebElement carticon;
	@FindBy(xpath="//button[@id='remove-sauce-labs-backpack']")
	WebElement removeitem;
	@FindBy(xpath="//div[text()='Sauce Labs Bolt T-Shirt']")
	WebElement item3title;
	@FindBy(xpath="//div[text()='Sauce Labs Backpack']")
	WebElement item1title;
	@FindBy(xpath="//div[@class='inventory_item_name']")
	WebElement cartitems;
	
	ArrayList<String> arr=new ArrayList<String>();
	ArrayList<String> cartlist=new ArrayList<String>();
	
	public int cartsize;
	public int removedcartsize;
	
	
	
	  WebDriver driver;
     public removeitempage(WebDriver driver) {
		 this.driver = driver;
			PageFactory.initElements(driver, this);
	 }
     
     
     public void removeproduct() throws InterruptedException {
    	 Thread.sleep(3000);
    	 arr.add(item3.getText());
    	 item3.click();
    	 Thread.sleep(3000);
    	 arr.add(item1.getText());
    	 cartsize=arr.size();
    	 item1.click();
    	 Thread.sleep(3000);
    	 carticon.click();
    	 Thread.sleep(3000);
    	 System.out.println(item3title.isDisplayed());
 		 System.out.println(item1title.isDisplayed());
    	 Thread.sleep(3000);
    	 removeitem.click();
         cartlist.add(cartitems.getText());
    	 Thread.sleep(3000);
    	 removedcartsize=cartlist.size();
    	 
    	 if(cartsize!=removedcartsize) 
    	 {
    		 System.out.println("Second product is removed from cart");
    	 }
    	 else
    	 {
    		 System.out.println("Second product is not removed from cart"); 
    	 }
    	
    	
     }
}
