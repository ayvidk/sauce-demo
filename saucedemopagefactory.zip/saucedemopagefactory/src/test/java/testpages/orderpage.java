package testpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
//scenario4

public class orderpage {
	@FindBy(xpath="//select[@class='product_sort_container']")
	WebElement dropdown;
	@FindBy(xpath="//button[@id ='add-to-cart-sauce-labs-onesie']")
	WebElement item1;
	@FindBy(xpath="//button[@id = 'add-to-cart-sauce-labs-bike-light']")
	WebElement item2;
	@FindBy(xpath="//button[@id = 'add-to-cart-sauce-labs-fleece-jacket']")
	WebElement item3;
	@FindBy(xpath="//*[@class = 'shopping_cart_link']")
	WebElement carticon;
	@FindBy(xpath="//button[@id = 'checkout']")
	WebElement Checkout;
	@FindBy(xpath="//input[@id = 'first-name']")
	WebElement firstname;
	@FindBy(xpath="//input[@id = 'last-name']")
	WebElement lastname;
	@FindBy(xpath="//input[@id = 'postal-code']")
	WebElement postalcode;
	@FindBy(xpath="//input[@id = 'continue']")
	WebElement Continue;
	@FindBy(xpath="//button[@id = 'finish']")
	WebElement Finish;
	@FindBy(xpath="//button[text()='Back Home']")
	WebElement backtohome;
	@FindBy(xpath="//span[@class='active_option']")
	WebElement priceselecttitle;
	@FindBy(xpath="//div[@class='complete-text']")
	WebElement ordermsg;
	
	
 WebDriver driver;
	 
	 public orderpage(WebDriver driver) {
		 this.driver = driver;
		 PageFactory.initElements(driver, this);
	 }
	 
	 public void orderproducts() throws InterruptedException {
		 Select name= new Select(dropdown);
			Thread.sleep(3000);
			name.selectByValue("lohi");
			Thread.sleep(3000);
			System.out.println("The products are displayed with price low to high is " + priceselecttitle.isEnabled());
			
			item1.click();
			Thread.sleep(3000);
			item2.click();
			Thread.sleep(3000);
			item3.click();
			Thread.sleep(3000);
			carticon.click();
			Thread.sleep(3000);
			Checkout.click();
			Thread.sleep(3000);
			firstname.sendKeys("Divya");
			Thread.sleep(3000);
			lastname.sendKeys("Katakam");
			Thread.sleep(3000);
			postalcode.sendKeys("505503");
			Thread.sleep(3000);
			Continue.click();
			Thread.sleep(3000);
			Finish.click();
			Thread.sleep(3000);
			System.out.println(ordermsg.isDisplayed());
			backtohome.click();
	 }

}
