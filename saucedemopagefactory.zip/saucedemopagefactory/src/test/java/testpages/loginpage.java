package testpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//scenario1

public class loginpage {
	@FindBy(css="#user-name")
	WebElement userName;
	@FindBy(css="#password")
	WebElement password;
	@FindBy(xpath="//input[@type='submit']")
	WebElement loginButton;
	private WebDriver driver;
	
	
	public loginpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void userlogin() throws InterruptedException {
		userName.sendKeys("standard_user");
		Thread.sleep(5000);
		password.sendKeys("secret_sauce");
		Thread.sleep(5000);
		loginButton.click();
	}

}
