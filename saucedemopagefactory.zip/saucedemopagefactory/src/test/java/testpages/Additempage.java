package testpages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//scenario1
public class Additempage {
	@FindBy(xpath="//button[@id=\"add-to-cart-test.allthethings()-t-shirt-(red)\"]")
	WebElement LastProduct;
	
	@FindBy(xpath="//*[@class=\"shopping_cart_link\"]")
	WebElement carticon;
	
	@FindBy(css="#item_3_title_link")
	WebElement lastitemtitle;
	
	
	
	 WebDriver driver;
	
	
	public  Additempage(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void selectProduct() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;  
        js.executeScript("scrollBy(0, 400)");
        Thread.sleep(3000);
		LastProduct.click();
		Thread.sleep(5000);
		carticon.click();
		String product=lastitemtitle.getText();
		System.out.println(lastitemtitle.isDisplayed());
		Thread.sleep(5000);
		System.out.println(product);
	}


}
