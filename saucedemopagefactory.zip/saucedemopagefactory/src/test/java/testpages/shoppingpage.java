package testpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
//scenario2

public class shoppingpage {
	@FindBy(xpath="//button[@id = 'add-to-cart-sauce-labs-bolt-t-shirt']")
	WebElement selectthirditem;
	
	@FindBy(xpath="//*[@class = 'shopping_cart_link']")
	WebElement carticon;
	
	@FindBy(xpath="//button[@id = 'continue-shopping']")
	WebElement continueshopping;

	@FindBy(xpath="//div[@class='inventory_item_name']")
	WebElement thirditemtitle;

	@FindBy(xpath="//div[@class='inventory_item_price']")
	WebElement priceofitem;
	
	
	
	 WebDriver driver;
	 
	 public shoppingpage(WebDriver driver) {
		 this.driver = driver;
			PageFactory.initElements(driver, this);
	 }
	 
	 public void Clickcontinueshopping() throws InterruptedException {
		 Thread.sleep(3000);
		 selectthirditem.click();
		 Thread.sleep(3000);
		 carticon.click();
		 Thread.sleep(3000);
		 System.out.println(thirditemtitle.isDisplayed());
		 System.out.println(priceofitem.isDisplayed());
		 Thread.sleep(3000);
		 continueshopping.click();
		 Thread.sleep(3000);
		  String my_homepage = driver.getTitle();
		  System.out.println("homepage title is " + my_homepage);
		  String expected_homepage = "Swag Labs";
		  Assert.assertTrue(my_homepage.contains("Swag Labs"));
		 
		 
	 }

}
